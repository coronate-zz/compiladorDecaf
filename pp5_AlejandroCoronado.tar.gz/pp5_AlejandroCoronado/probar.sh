echo "\n\n\n"
echo "-----------------------01--------------------------------"
./run samples/badlink.decaf
echo "\n\n\n"
echo "-----------------------02--------------------------------"

./run samples/badnewarr.decaf
echo "\n\n\n"
echo "-----------------------03--------------------------------"

./run samples/badsub.decaf
echo "\n\n\n"
echo "-----------------------04--------------------------------"

#./run samples/blackjack.decaf

echo "\n\n\n"
echo "-----------------------05--------------------------------"
./run samples/factorial.decaf

echo "\n\n\n"
echo "-----------------------06--------------------------------"
./run samples/fib.decaf

echo "\n\n\n"
echo "-----------------------07--------------------------------"
./run samples/matrix.decaf
echo "\n\n\n"
echo "-----------------------08--------------------------------"
./run samples/queue.decaf
echo "\n\n\n"
echo "-----------------------09--------------------------------"
./run samples/sort.decaf
echo "\n\n\n"
echo "-----------------------10--------------------------------"
./run samples/stack.decaf
echo "\n\n\n"
echo "-----------------------11--------------------------------"
./run samples/t1.decaf
echo "\n\n\n"
echo "-----------------------12--------------------------------"
./run samples/t2.decaf
echo "\n\n\n"
echo "-----------------------13--------------------------------"
./run samples/t3.decaf
echo "\n\n\n"
echo "-----------------------14--------------------------------"
./run samples/t4.decaf
echo "\n\n\n"
echo "-----------------------15--------------------------------"
./run samples/t5.decaf
echo "\n\n\n"
echo "-----------------------16--------------------------------"
./run samples/t6.decaf
echo "\n\n\n"
echo "-----------------------17--------------------------------"
./run samples/t7.decaf
echo "\n\n\n"
echo "-----------------------18--------------------------------"
./run samples/t8.decaf

